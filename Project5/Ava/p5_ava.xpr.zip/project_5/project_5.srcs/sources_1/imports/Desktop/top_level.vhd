library ieee ;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity top_level is
    port(
        clk         : in std_logic;
        usb_tx      : in std_logic;
        usb_rx      : out std_logic;
        ps2_clk     : in std_logic; 
        ps2_data    : in std_logic;
        A_x           : in std_logic;
        B_x           : in std_logic;
        A_y           : in std_logic;
        B_y           : in std_logic
     --   oSDA        : inout std_logic;
     --   oSCL        : inout std_logic
    );
end top_level;

architecture arch of top_level is

    component Reset_Delay IS  
        PORT (
            SIGNAL iCLK : IN std_logic; 
            SIGNAL oRESET : OUT std_logic
        );  
    END component;

    component clk_enabler is
        GENERIC (
            CONSTANT cnt_max : integer := 49999999);      --  1.0 Hz
        port(    
            clock:        in std_logic;     
            clk_en:       out std_logic
        );
    end component;

    component ps2_keyboard_to_ascii IS
        GENERIC(
              clk_freq                  : INTEGER := 125_000_000; --system clock frequency in Hz
              ps2_debounce_counter_size : INTEGER := 10);         --set such that 2^size/clk_freq = 5us (size = 8 for 50MHz)
        PORT(
              clk        : IN  STD_LOGIC;                     --system clock input
              ps2_clk    : IN  STD_LOGIC;                     --clock signal from PS2 keyboard
              ps2_data   : IN  STD_LOGIC;                     --data signal from PS2 keyboard
              ascii_new  : OUT STD_LOGIC;                     --output flag indicating new ASCII value
              ascii_code : OUT STD_LOGIC_VECTOR(7 DOWNTO 0)); --ASCII value
        END component;

    component uart is
        port (
                reset       :in  std_logic;
                txclk       :in  std_logic;
                ld_tx_data  :in  std_logic;
                tx_data     :in  std_logic_vector (7 downto 0);
                tx_enable   :in  std_logic;
                tx_out      :out std_logic;
                tx_empty    :out std_logic;
                rxclk       :in  std_logic;
                uld_rx_data :in  std_logic;
                rx_data     :out std_logic_vector (7 downto 0);
                rx_enable   :in  std_logic;
                rx_in       :in  std_logic;
                rx_empty    :out std_logic
            );
        end component;

    component rotary is
        generic(N: integer := 8; N2: integer := 255; N1: integer := 0);
        port (
        iCLK                    : in std_logic; 
        reset                   : in std_logic;
        A                       : in std_logic; -- A value
        B                       : in std_logic; -- B value
        left_tick               : out std_logic;
        right_tick              : out std_logic
        );
    end component;

    signal sig_count_out : std_logic_vector(7 downto 0);    
    signal reset_on         : std_logic;
    signal rx_clken         : std_logic;
    signal tx_clken         : std_logic;
    signal ascii_new        : std_logic;
    signal ascii_data_ps2   : std_logic_vector(7 downto 0);
    signal uart_rx_data     : std_logic_vector(7 downto 0);
    signal uart_tx_data     : std_logic_vector(7 downto 0);
    signal tx_out_sel       : std_logic;  -- Control signal to select data source
    signal ld_tx_data       : std_logic;
    signal cursor_x        : integer := 0;                     -- X cursor position
    signal cursor_y        : integer := 0;                     -- Y cursor position
    signal direction       : std_logic_vector(7 downto 0);      -- Direction output (UP or DOWN)
    signal sig_count_out_x   : std_logic_vector(7 downto 0);    -- X Cursor position output
    signal sig_count_out_y   : std_logic_vector(7 downto 0);    -- Y Cursor position output
    signal direction_x       : std_logic_vector(7 downto 0);      -- X Direction output (UP or DOWN)
    signal direction_y       : std_logic_vector(7 downto 0);      -- Y Direction output (UP or DOWN)
    signal uart_wr            : std_logic := '0';    
    signal rotary_x_left_tick  : std_logic;
    signal rotary_x_right_tick : std_logic;
    signal rotary_y_left_tick  : std_logic;
    signal rotary_y_right_tick : std_logic;
    signal prev_x_left_tick   : std_logic := '0';
    signal prev_x_right_tick  : std_logic := '0';
    signal prev_y_left_tick   : std_logic := '0';
    signal prev_y_right_tick  : std_logic := '0';

    type state_type is (IDLE, SENT);
    signal state : state_type := IDLE;

begin 

    inst_reset_delay: reset_delay 
        port map(
            iclk    => clk,
            oRESET  => reset_on
        );

    inst_tx_clken: clk_enabler
        GENERIC map (cnt_max => 13201)    
            port map(    
                clock   => clk, 
                clk_en  => tx_clken
            );

    inst_rx_clken: clk_enabler
        GENERIC map (cnt_max => 800)    
            port map(    
                clock   => clk, 
                clk_en  => rx_clken
       );

    -- PS2 Keyboard Component
    inst_keyboard: ps2_keyboard_to_ascii
        GENERIC map(
              clk_freq                  => 125000000, 
              ps2_debounce_counter_size => 10)         
        PORT map(
              clk        => clk,
              ps2_clk    => ps2_clk,
              ps2_data   => ps2_data,
              ascii_new  => ascii_new,
              ascii_code => ascii_data_ps2
        );

    -- Rotary Encoder Component
  inst_rotary_x: rotary
        port map (
            iCLK        => clk,
            reset       => reset_on,
            A           => A_x,
            B           => B_x,
            left_tick   => rotary_x_left_tick,
            right_tick  => rotary_x_right_tick
        );

    -- Rotary Encoder for Y (reuse A/B for demo or expand as needed)
    inst_rotary_y: rotary
        port map (
            iCLK        => clk,
            reset       => reset_on,
            A           => A_y,
            B           => B_y,
            left_tick   => rotary_y_left_tick,
            right_tick  => rotary_y_right_tick
        );

    inst_uart_kb: uart
        port map(
            reset       => reset_on,
            txclk       => tx_clken,
            ld_tx_data  => '1',
            tx_data     => uart_tx_data,
            tx_enable   => '1',
            tx_out      => usb_rx,
            tx_empty    => open,
            rxclk       => rx_clken,
            uld_rx_data => '1',
            rx_data     => uart_rx_data,
            rx_enable   => '1',
            rx_in       => usb_tx,
            rx_empty    => open
        );

    -- Rotary direction FSM to UART data mapping


process(clk, reset_on)
begin
    if reset_on = '1' then
        uart_tx_data <= (others => '0');
        uart_wr <= '0';

        prev_x_left_tick   <= '0';
        prev_x_right_tick  <= '0';
        prev_y_left_tick   <= '0';
        prev_y_right_tick  <= '0';

    elsif rising_edge(clk) then
        uart_wr <= '0'; -- default no write

        -- Rising edge detection
        if rotary_x_left_tick = '1' and prev_x_left_tick = '0' then
            uart_tx_data <= x"68"; -- 'f'
            uart_wr <= '1';
        elsif rotary_x_right_tick = '1' and prev_x_right_tick = '0' then
            uart_tx_data <= x"66"; -- 'h'
            uart_wr <= '1';
        elsif rotary_y_left_tick = '1' and prev_y_left_tick = '0' then
            uart_tx_data <= x"67"; -- 't'
            uart_wr <= '1';
        elsif rotary_y_right_tick = '1' and prev_y_right_tick = '0' then
            uart_tx_data <= x"74"; -- 'g'
            uart_wr <= '1';
        end if;

        -- Store previous states
        prev_x_left_tick   <= rotary_x_left_tick;
        prev_x_right_tick  <= rotary_x_right_tick;
        prev_y_left_tick   <= rotary_y_left_tick;
        prev_y_right_tick  <= rotary_y_right_tick;
    end if;
end process;


end arch;
