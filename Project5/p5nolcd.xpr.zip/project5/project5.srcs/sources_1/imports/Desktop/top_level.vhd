library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity top_level is
    port(
        clk         : in std_logic;
        usb_tx      : in std_logic;
        usb_rx      : out std_logic;
        ps2_clk     : in std_logic;
        ps2_data    : in std_logic;
        Ax          : in std_logic;
        Bx          : in std_logic;
        Ay          : in std_logic;
        By          : in std_logic;
        btn         : in std_logic  -- input mode
    );
end top_level;

architecture arch of top_level is

    -- Declare necessary components
    component Reset_Delay is
        port (
            iCLK   : in std_logic;
            oRESET : out std_logic
        );
    end component;

    component clk_enabler is
        generic (
            cnt_max : integer := 49999999
        );
        port(
            clock   : in std_logic;
            clk_en  : out std_logic
        );
    end component;

    component ps2_keyboard_to_ascii is
        generic(
            clk_freq                  : integer := 125000000;
            ps2_debounce_counter_size : integer := 10
        );
        port(
            clk         : in  std_logic;
            ps2_clk     : in  std_logic;
            ps2_data    : in  std_logic;
            ascii_new   : out std_logic;
            ascii_code  : out std_logic_vector(7 downto 0)
        );
    end component;

    component uart is
        port (
            reset       : in  std_logic;
            txclk       : in  std_logic;
            ld_tx_data  : in  std_logic;
            tx_data     : in  std_logic_vector (7 downto 0);
            tx_enable   : in  std_logic;
            tx_out      : out std_logic;
            tx_empty    : out std_logic;
            rxclk       : in  std_logic;
            uld_rx_data : in  std_logic;
            rx_data     : out std_logic_vector (7 downto 0);
            rx_enable   : in  std_logic;
            rx_in       : in  std_logic;
            rx_empty    : out std_logic
        );
    end component;

    component rotary is
        generic(N: integer := 8; N2: integer := 255; N1: integer := 0);
        port (
            iCLK          : in std_logic;
            A             : in std_logic;
            B             : in std_logic;
            count_out     : out std_logic_vector(N-1 downto 0);
            direction_out : out std_logic_vector(7 downto 0);
            pulse_out     : out std_logic
        );
    end component;


    signal reset_on          : std_logic;
    signal rx_clken          : std_logic;
    signal tx_clken          : std_logic;
    signal ascii_new         : std_logic;
    signal ascii_data_ps2    : std_logic_vector(7 downto 0);
    signal uart_rx_data      : std_logic_vector(7 downto 0);
    signal rx_empty          : std_logic;
    signal dir_x, dir_y      : std_logic_vector(7 downto 0);
    signal count_x, count_y  : std_logic_vector(7 downto 0);
    signal pulse_x, pulse_y  : std_logic;
    signal ascii_muxed       : std_logic_vector(7 downto 0);
    signal ascii_new_muxed   : std_logic;
    signal selector          : std_logic_vector(1 downto 0) := "00";
    signal btn_prev          : std_logic := '0';

-- state machine stuff------------------------------------------------------
    type state_type is (idle, horz, vert, ps2);    
    signal state  : state_type := idle;  -- State machine state
    signal countx_prev   : std_logic_vector(7 downto 0);
    signal county_prev   : std_logic_vector(7 downto 0);
    signal count_pulse   : std_logic;
    signal county_pulse  : std_logic;
    signal counter       : integer range 0 to 13201 := 0;
    signal countery      : integer range 0 to 13201 := 0;
    signal countx_at_pulse : std_logic_vector(7 downto 0);
    signal countx_new    : std_logic_vector(7 downto 0);
    signal county_at_pulse : std_logic_vector(7 downto 0);
    signal county_new    : std_logic_vector(7 downto 0);
    signal ld_tx_data    : std_logic;
    signal tx_data       : std_logic_vector(7 downto 0);


begin
-- inst ---------------------------------------------------------------------
    inst_reset_delay: Reset_Delay
        port map(
            iCLK    => clk,
            oRESET  => reset_on
        );

    inst_tx_clken: clk_enabler
        generic map (cnt_max => 13201)
        port map(
            clock   => clk,
            clk_en  => tx_clken
        );

    inst_rx_clken: clk_enabler
        generic map (cnt_max => 800)
        port map(
            clock   => clk,
            clk_en  => rx_clken
        );

    inst_keyboard: ps2_keyboard_to_ascii
        generic map(
            clk_freq => 125000000,
            ps2_debounce_counter_size => 10
        )
        port map(
            clk         => clk,
            ps2_clk     => ps2_clk,
            ps2_data    => ps2_data,
            ascii_new   => ascii_new,
            ascii_code  => ascii_data_ps2
        );

    inst_rotary_x: rotary
        port map(
            iCLK          => clk,
            A             => Ax,
            B             => Bx,
            count_out     => count_x,
            direction_out => dir_x,
            pulse_out     => pulse_x
        );

    inst_rotary_y: rotary
        port map(
            iCLK          => clk,
            A             => Ay,
            B             => By,
            count_out     => count_y,
            direction_out => dir_y,
            pulse_out     => pulse_y
        );

        

    inst_uart: uart
        port map(
            reset       => reset_on,
            txclk       => tx_clken,
            ld_tx_data  => ld_tx_data,
            tx_data     => tx_data,
            tx_enable   => '1',
            tx_out      => usb_rx,
            tx_empty    => open,
            rxclk       => rx_clken,
            uld_rx_data => '1',
            rx_data     => uart_rx_data,
            rx_enable   => '1',
            rx_in       => usb_tx,
            rx_empty    => rx_empty
        );

-- selector for input modes (not sure if its actually being used --------------------------------------------
    process(clk)
    begin
        if rising_edge(clk) then
            if btn = '1' and btn_prev = '0' then
                case selector is
                    when "00" => selector <= "01";
                    when "01" => selector <= "10";
                    when others => selector <= "00";
                end case;
            end if;
            btn_prev <= btn;
        end if;
    end process;

-- pulse gen-------------------------------------------------------------
    process(clk)
    begin
        if rising_edge(clk) then
            countx_prev <= count_x;
            county_prev <= count_y;
            
            if count_x /= countx_prev then
                count_pulse <= '1';
                counter <= 0;
                countx_at_pulse <= countx_prev; 
                countx_new <= count_x;           
            elsif count_pulse = '1' then
                if counter < 13201 then
                    counter <= counter + 1;
                else
                    count_pulse <= '0';
                end if;
            end if;

            if count_y /= county_prev then
                county_pulse <= '1';
                countery <= 0;
                county_at_pulse <= county_prev; 
                county_new <= count_y;          
            elsif county_pulse = '1' then
                if countery < 13201 then
                    countery <= countery + 1;
                else
                    county_pulse <= '0';
                end if;
            end if;
        end if;
    end process;

-- state machine for detecting a pulse from each  ---------------
    process(clk)
    begin
        if rising_edge(clk) then
            if reset_on = '1' then
                state <= idle;
            else
                case state is
                    when idle =>
                        ld_tx_data <= '0';
                        if count_pulse = '1' then
                            state <= horz;
                        elsif county_pulse = '1' then
                            state <= vert;
                        elsif ascii_new = '1' then
                            state <= ps2;
                        end if;

                    when horz =>
                        ld_tx_data <= '1';
                        if countx_new > countx_at_pulse then
                            tx_data <= x"6A";  -- 'j'
                            ld_tx_data <= '1';
                        elsif countx_new < countx_at_pulse then
                            tx_data <= x"67";  -- 'g'
                            ld_tx_data <= '1';
                        end if;

                        if count_pulse = '0' then
                            state <= idle;
                        end if;

                    when vert =>
                        ld_tx_data <= '1';
                        if county_new > county_at_pulse then
                            tx_data <= x"68";  -- 'h'
                            ld_tx_data <= '1';
                        elsif county_new < county_at_pulse then
                            tx_data <= x"79";  -- 'y'
                            ld_tx_data <= '1';
                        end if;

                        if county_pulse = '0' then
                            state <= idle;
                        end if;

                    when ps2 =>
                        ld_tx_data <= '1';
                        tx_data <= ascii_data_ps2;
                        if ascii_new = '0' then
                            state <= idle;
                        end if;

                    when others =>
                        state <= idle;
                end case;
            end if;
        end if;
    end process;

end arch;
