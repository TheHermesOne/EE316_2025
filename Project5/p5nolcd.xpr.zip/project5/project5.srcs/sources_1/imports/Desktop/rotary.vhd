library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.numeric_std.all;

entity rotary is
    generic(N: integer := 8; N2: integer := 255; N1: integer := 0);
    port (
        iCLK          : in std_logic;
        A             : in std_logic;
        B             : in std_logic;
        count_out     : out std_logic_vector(N-1 downto 0);
        direction_out : out std_logic_vector(7 downto 0);
        pulse_out     : out std_logic  -- 1-cycle pulse on valid step
    );
end rotary;

architecture Arch of rotary is

    component btn_debounce_toggle is
        generic (
            CNTR_MAX : std_logic_vector(15 downto 0) := X"FFFF"
        );
        port(
            BTN_I    : in std_logic;
            clk      : in std_logic;
            BTN_O    : out std_logic;
            TOGGLE_O : out std_logic;
            PULSE_O  : out std_logic
        );
    end component;

    signal A_db, B_db       : std_logic := '0';
    signal A_prev, B_prev   : std_logic := '0';
    signal count            : integer := 0;

    signal A_pulse          : std_logic := '0';

begin

    process(iCLK)
    begin
        if rising_edge(iCLK) then
            A_prev <= A_db;
            B_prev <= B_db;

            if (A_prev = '0' and A_db = '1') then
                if B_db = '0' then
                    direction_out <= X"55";  -- CW
                    count <= count + 1;
                else
                    direction_out <= X"44";  -- CCW
                    count <= count - 1;
                end if;
            end if;

            count_out <= std_logic_vector(to_unsigned(count, N));
        end if;
    end process;

    pulse_out <= A_pulse;

    inst_A: btn_debounce_toggle
        generic map(CNTR_MAX => X"FFFF")
        port map(
            BTN_I     => A,
            clk       => iCLK,
            BTN_O     => A_db,
            TOGGLE_O  => open,
            PULSE_O   => A_pulse
        );

    inst_B: btn_debounce_toggle
        generic map(CNTR_MAX => X"FFFF")
        port map(
            BTN_I     => B,
            clk       => iCLK,
            BTN_O     => B_db,
            TOGGLE_O  => open,
            PULSE_O   => open
        );

end Arch;
