LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;


ENTITY LCD_Controller IS
    PORT (
        Reset        : IN std_logic;
        Data         : IN std_logic_vector(7 DOWNTO 0);
        iclk          : IN std_logic;
        LCD_RS, LCD_EN : OUT std_logic;
        LCD_DATA      : OUT std_logic_vector(7 DOWNTO 0)
    );
END LCD_Controller;

ARCHITECTURE arch OF LCD_Controller IS

    component clk_enabler IS
        generic (constant cnt_max : integer := 50000000);
        PORT (
            clock   : IN std_logic;
            clk_en  : OUT std_logic
        );
    end component;
    


        TYPE STATE_TYPE IS (STATE0, STATE1, STATE2);
        SIGNAL STATE                        : STATE_TYPE;
        SIGNAL Data_sent                    : STD_LOGIC_VECTOR (8 downto 0);
        SIGNAL LUT_INDEX                    : integer range 0 to 63:= 0;
        SIGNAL LCD_DATA_VALUE               : STD_LOGIC_VECTOR(7 downto 0);
        SIGNAL LCD_clock_en, stp_clk_en     : std_logic;
        
        
        type array_type is array (0 to 7) of std_logic_vector(7 downto 0);
        signal ascii : array_type;
        
   BEGIN
        
        LCD_DATA         <= data_sent(7 downto 0);
        LCD_RS          <= DATA_sent(8);
        
        inst_clk_enabler: clk_enabler
        generic map(cnt_max => 83333
            )
        port map    (
           clock     => iCLK,
           clk_en    => LCD_clock_en
           );
           
        process (LUT_INDEX, data)
        BEGIN
            case LUT_INDEX IS
                WHEN 0      => data_sent <= "0"&X"38";
                WHEN 1      => data_sent <= "0"&X"38";
                WHEN 2      => data_sent <= "0"&X"38";
                WHEN 3      => data_sent <= "0"&X"38";
                WHEN 4      => data_sent <= "0"&X"38";
                WHEN 5      => data_sent <= "0"&X"38";
                WHEN 6      => data_sent <= "0"&X"01";
                WHEN 7      => data_sent <= "0"&X"0C";
                WHEN 8      => data_sent <= "0"&X"06";
                WHEN 9      => data_sent <= "0"&X"80";
                
                WHEN 10      => data_sent <= "1"&X"53";
                WHEN 11      => data_sent <= "1"&X"79";
                WHEN 12      => data_sent <= "1"&X"73";
                WHEN 13      => data_sent <= "1"&X"74";
                WHEN 14      => data_sent <= "1"&X"65";
                WHEN 15      => data_sent <= "1"&X"6D";
                WHEN 16      => data_sent <= "1"&X"FE";
                WHEN 17      => data_sent <= "1"&X"52";
                WHEN 18      => data_sent <= "1"&X"65";
                WHEN 19      => data_sent <= "1"&X"61";
                WHEN 20      => data_sent <= "1"&X"64";
                WHEN 21      => data_sent <= "1"&X"79";
                
                
                WHEN 22      => data_sent <= "0"&X"C0";
                WHEN 23      => data_sent <= "1"&X"3D";
                WHEN 24      => data_sent <= "1"&X"3D";
                WHEN 25      => data_sent <= "1"&X"3E";
                WHEN 26      => data_sent <= "1"&data;
                WHEN OTHERS => data_sent <= "0"&X"01";
              END CASE;
           END PROCESS;
      
       Process (iclk, reset)
       BEGIN
        IF Reset = '1' THEN
                STATE <= STATE0;
                LCD_EN <= '0';
                LUT_INDEX <= 0;
        ELSIF RISING_EDGE(iclk) AND LCD_clock_en = '1' THEN
            CASE STATE IS
                WHEN STATE0 =>
                    LCD_EN <= '1';
                    STATE <= STATE1;
                WHEN STATE1 =>
                    LCD_EN <= '0';
                    STATE <= STATE2;
                WHEN STATE2 =>
                    LCD_EN <= '0';
                    STATE <= STATE0;
                    IF LUT_INDEX < 26 THEN
                        LUT_INDEX <= LUT_INDEX + 1;
                    ELSE
                        LUT_INDEX <= 22;
                    END IF;
                WHEN OTHERS =>
                    STATE <= STATE0;
            END CASE;
        END IF;
     end process;


end arch;            